


public class Dilwseis extends Courses{
    public Dilwseis(int id, String name, char exam) {
        super(id, name, exam);
        
    }

   
    public void createDilwseis() {
        Student obj;
        //listCourses[i].id=id;
    }
     
}
